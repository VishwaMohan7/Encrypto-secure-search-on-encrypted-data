import hashlib
import json

# secret key (keep private)
SECRET_KEY = "super_secret_key"

# load processed data from step 2
with open("processed_data.json", "r") as f:
    processed_docs = json.load(f)

encrypted_index = {}

# function to generate trapdoor (secure hash)
def generate_trapdoor(word):
    data = word + SECRET_KEY
    return hashlib.sha256(data.encode()).hexdigest()

# build encrypted inverted index
for doc, words in processed_docs.items():
    for word in words:
        trapdoor = generate_trapdoor(word)

        if trapdoor not in encrypted_index:
            encrypted_index[trapdoor] = []

        if doc not in encrypted_index[trapdoor]:
            encrypted_index[trapdoor].append(doc)

# save encrypted index
with open("encrypted_index.json", "w") as f:
    json.dump(encrypted_index, f, indent=4)

print("✅ Encrypted index created successfully")
print("Total unique keywords:", len(encrypted_index))