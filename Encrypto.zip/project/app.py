from flask import Flask, render_template, request, redirect, session
import json
import hashlib
import time

# store user search timestamps
user_activity_log = {}

# security thresholds
MAX_SEARCH_PER_MINUTE = 3
BLOCK_TIME_SECONDS = 60

blocked_users = {}
app = Flask(__name__)
app.secret_key = "session_secret_key"

SECRET_KEY = "super_secret_key"

# -------------------------
# SIMPLE USER DATABASE (IDP USERS)
# -------------------------
USERS = {
    "admin": {"password": "admin123", "role": "admin"},
    "user": {"password": "user123", "role": "user"}
}

# -------------------------
# LOAD ENCRYPTED INDEX
# -------------------------
with open("encrypted_index.json") as f:
    encrypted_index = json.load(f)

# -------------------------
# LOAD RSA-ENCRYPTED AES KEY
# IMPORTANT: DO NOT BASE64 AGAIN
# -------------------------
with open("encrypted_aes.key", "r") as f:
    encrypted_aes_key = f.read().strip()

# -------------------------
# TRAPDOOR GENERATION
# -------------------------
def generate_trapdoor(word):
    return hashlib.sha256((word + SECRET_KEY).encode()).hexdigest()

def check_access_anomaly(user):

    current_time = time.time()

    # check if user already blocked
    if user in blocked_users:
        if current_time < blocked_users[user]:
            return True, "⚠ You are temporarily blocked due to suspicious activity."
        else:
            del blocked_users[user]

    # initialize user log
    if user not in user_activity_log:
        user_activity_log[user] = []

    # store current search time
    user_activity_log[user].append(current_time)

    # keep only last 1 minute activity
    user_activity_log[user] = [
        t for t in user_activity_log[user]
        if current_time - t < 60
    ]

    # check threshold
    if len(user_activity_log[user]) > MAX_SEARCH_PER_MINUTE:
        blocked_users[user] = current_time + BLOCK_TIME_SECONDS
        return True, "⚠ Suspicious activity detected. Access blocked for 1 minute."

    return False, None
# -------------------------
# LOGIN (IDP AUTHENTICATION)
# -------------------------
@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        if username in USERS and USERS[username]["password"] == password:
            session["user"] = username
            session["role"] = USERS[username]["role"]
            return redirect("/")

        return "Invalid credentials"

    return render_template("login.html")

# -------------------------
# LOGOUT
# -------------------------
@app.route("/logout")
def logout():
    session.clear()
    return redirect("/login")

# -------------------------
# HOME (PROTECTED)
# -------------------------
@app.route("/")
def home():

    if "user" not in session:
        return redirect("/login")

    return render_template("index.html", user=session["user"])

# -------------------------
# VIEW DOCUMENT (AUTHORIZED ONLY)
# -------------------------
@app.route("/view/<filename>")
def view_document(filename):

    if "user" not in session:
        return redirect("/login")

    if session.get("role") != "admin":
        return "❌ Access denied. Only admin can view documents."

    file_path = "encrypted_docs/" + filename

    import base64

    # send encrypted document as base64
    with open(file_path, "rb") as f:
        encrypted_data = base64.b64encode(f.read()).decode()

    return render_template(
        "view_document.html",
        filename=filename,
        encrypted_data=encrypted_data,
        encrypted_key=encrypted_aes_key
    )

# -------------------------
# SEARCH ROUTE (SECURE + AND MATCHING)
# -------------------------
@app.route("/search", methods=["POST"])
def search():

    if "user" not in session:
        return redirect("/login")
    user = session["user"]

    blocked, message = check_access_anomaly(user)

    if blocked:
        return message

    query = request.form["query"].lower().strip()

    if not query:
        return render_template("results.html", results=[], query=query)

    query_tokens = query.split()
    doc_sets = []

    for word in query_tokens:
        trapdoor = generate_trapdoor(word)
        docs = set(encrypted_index.get(trapdoor, []))
        doc_sets.append(docs)

    # AND matching
    if doc_sets:
        candidate_docs = set.intersection(*doc_sets)
    else:
        candidate_docs = set()

    results = [
        {"doc": doc, "score": "Encrypted Match"}
        for doc in candidate_docs
    ]

    return render_template("results.html", results=results, query=query)

# -------------------------
# RUN APP
# -------------------------
if __name__ == "__main__":
    app.run(debug=True)