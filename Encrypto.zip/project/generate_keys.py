from Crypto.PublicKey import RSA

key = RSA.generate(2048)

# PKCS8 → required for browser WebCrypto
private_key = key.export_key(format="PEM", pkcs=8)
public_key = key.publickey().export_key(format="PEM")

open("private.pem","wb").write(private_key)
open("public.pem","wb").write(public_key)

print("keys generated")