import json
import hashlib
from Crypto.Cipher import AES
from ranker import rank_documents

SECRET_KEY = "super_secret_key"

print("\n🔐 Secure Search System Started\n")

# ============================
# LOAD FILES SAFELY
# ============================

try:
    with open("encrypted_index.json") as f:
        encrypted_index = json.load(f)
except FileNotFoundError:
    print("❌ encrypted_index.json not found. Run build_index.py first.")
    exit()

try:
    with open("secret.key", "rb") as f:
        aes_key = f.read()
except FileNotFoundError:
    print("❌ secret.key not found. Run encrypt_docs.py first.")
    exit()

# ============================
# FUNCTIONS
# ============================

# generate secure trapdoor
def generate_trapdoor(word):
    return hashlib.sha256((word + SECRET_KEY).encode()).hexdigest()

# decrypt AES encrypted file
def decrypt_file(file_path):
    with open(file_path, "rb") as f:
        data = f.read()

    nonce = data[:16]
    tag = data[16:32]
    ciphertext = data[32:]

    cipher = AES.new(aes_key, AES.MODE_EAX, nonce=nonce)
    return cipher.decrypt_and_verify(ciphertext, tag)

# ============================
# USER QUERY
# ============================

query = input("Enter keyword to search: ").lower().strip()

if not query:
    print("❌ Empty query not allowed")
    exit()

if len(query) < 2:
    print("❌ Query too short")
    exit()

print("\n📌 Query received:", query)

# ============================
# TRAPDOOR GENERATION
# ============================

trapdoor = generate_trapdoor(query)

print("\n🔑 Generated Trapdoor (Hash):")
print(trapdoor)

# ============================
# ENCRYPTED INDEX MATCHING
# ============================

matching_docs = encrypted_index.get(trapdoor, [])

print("\n🔍 Matching encrypted documents:", matching_docs)

if not matching_docs:
    print("\n❌ No matching documents found")
    exit()

# ============================
# ML RANKING
# ============================

print("\n📊 Ranking documents using TF-IDF...")

ranked_results = rank_documents(query, matching_docs)

print("\n⭐ Ranked Results:")
for doc, score in ranked_results:
    print(f"{doc} → Score: {round(score, 3)}")

# ============================
# DECRYPT RESULTS
# ============================

print("\n🔓 Decrypting matched documents...")

for doc, score in ranked_results:
    try:
        content = decrypt_file("encrypted_docs/" + doc)

        print("\n==============================")
        print("📄 Document:", doc)
        print("==============================")
        print(content.decode())

    except FileNotFoundError:
        print(f"❌ Encrypted file not found: {doc}")

    except ValueError:
        print(f"❌ Decryption failed — data corrupted for {doc}")

    except Exception as e:
        print(f"❌ Unexpected error for {doc}: {e}")

print("\n✅ Search Completed Successfully")