from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from Crypto.Hash import SHA256
import base64

# load public key
public_key = RSA.import_key(open("public.pem","rb").read())

cipher = PKCS1_OAEP.new(public_key, hashAlgo=SHA256)

# read AES key as STRING
aes_key = open("secret.key","rb").read()

encrypted = cipher.encrypt(aes_key)

open("encrypted_aes.key","wb").write(base64.b64encode(encrypted))

print("AES key encrypted")