import json
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# load processed data
with open("processed_data.json") as f:
    processed_docs = json.load(f)

# convert token lists back to text format
doc_names = list(processed_docs.keys())
documents = [" ".join(words) for words in processed_docs.values()]

# create TF-IDF model
vectorizer = TfidfVectorizer()
tfidf_matrix = vectorizer.fit_transform(documents)

def rank_documents(query, matched_docs):
    if not matched_docs:
        return []

    # get indices of matched docs
    indices = [doc_names.index(doc) for doc in matched_docs]

    # transform query
    query_vec = vectorizer.transform([query])

    # compute similarity
    scores = cosine_similarity(query_vec, tfidf_matrix[indices])[0]

    # pair docs with scores and sort
    ranked = sorted(zip(matched_docs, scores), key=lambda x: x[1], reverse=True)

    return ranked