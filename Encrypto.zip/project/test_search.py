import json
import hashlib

SECRET_KEY = "super_secret_key"

def generate_trapdoor(word):
    return hashlib.sha256((word + SECRET_KEY).encode()).hexdigest()

# load index
with open("encrypted_index.json") as f:
    index = json.load(f)

query = input("Enter keyword: ").lower()

trapdoor = generate_trapdoor(query)

results = index.get(trapdoor, [])

print("Matching documents:", results)