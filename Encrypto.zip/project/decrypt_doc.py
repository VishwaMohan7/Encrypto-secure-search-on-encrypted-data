from Crypto.Cipher import AES

# load key
with open("secret.key", "rb") as f:
    key = f.read()

def decrypt_file(file_path):
    with open(file_path, "rb") as f:
        data = f.read()

    nonce = data[:16]
    tag = data[16:32]
    ciphertext = data[32:]

    cipher = AES.new(key, AES.MODE_EAX, nonce=nonce)
    return cipher.decrypt_and_verify(ciphertext, tag)

file = input("Enter encrypted file name: ")

decrypted = decrypt_file("encrypted_docs/" + file)
print(decrypted.decode())