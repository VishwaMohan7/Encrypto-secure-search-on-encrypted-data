import os
import re
import json
import nltk
from nltk.tokenize import word_tokenize

# download tokenizer (runs only first time)

nltk.download('punkt')
nltk.download('punkt_tab')

# folder where your documents are stored
DATA_FOLDER = "data"

processed_docs = {}

# read each document
for filename in os.listdir(DATA_FOLDER):
    file_path = os.path.join(DATA_FOLDER, filename)

    # read file content
    with open(file_path, "r", encoding="utf-8") as f:
        text = f.read()

        # STEP 1: convert to lowercase
        text = text.lower()

        # STEP 2: remove punctuation
        text = re.sub(r"[^\w\s]", "", text)

        # STEP 3: tokenize (split into words)
        words = word_tokenize(text)

        # store processed words
        processed_docs[filename] = words

# save processed output
with open("processed_data.json", "w") as f:
    json.dump(processed_docs, f, indent=4)

print("✅ Preprocessing completed")
print("Processed data saved to processed_data.json")