from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
import os

# ================================
# CONFIG
# ================================
INPUT_FOLDER = "data"              # original documents
OUTPUT_FOLDER = "encrypted_docs"  # encrypted output

os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# ================================
# LOAD AES KEY
# ================================
with open("secret.key", "rb") as f:
    key = f.read()

# validate key length (AES requires 16, 24, or 32 bytes)
if len(key) not in [16, 24, 32]:
    raise ValueError(
        f"❌ Invalid AES key length: {len(key)} bytes. Use 16, 24, or 32 bytes."
    )

print(f"✅ AES key loaded ({len(key)} bytes)")

# ================================
# ENCRYPT FILE FUNCTION
# ================================
def encrypt_file(file_path):

    with open(file_path, "rb") as f:
        data = f.read()

    # PKCS7 padding (standard)
    padded_data = pad(data, AES.block_size)

    # AES CBC encryption
    cipher = AES.new(key, AES.MODE_CBC)

    iv = cipher.iv
    ciphertext = cipher.encrypt(padded_data)

    # store IV + ciphertext
    return iv + ciphertext


# ================================
# ENCRYPT ALL FILES
# ================================
print("🔐 Encrypting documents...")

for filename in os.listdir(INPUT_FOLDER):

    path = os.path.join(INPUT_FOLDER, filename)

    if os.path.isfile(path):

        encrypted_data = encrypt_file(path)

        output_path = os.path.join(OUTPUT_FOLDER, filename)

        with open(output_path, "wb") as f:
            f.write(encrypted_data)

        print(f"✔ Encrypted: {filename}")

print("\n✅ All documents encrypted successfully")